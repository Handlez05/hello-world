<?php

return [
	'appVersion' => '5.2.2',
	'patchVersion' => '2019.09.09',
	'lib_roundcube' => '0.0.77'
];
