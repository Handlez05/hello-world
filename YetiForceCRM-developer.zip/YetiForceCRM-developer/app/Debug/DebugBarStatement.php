<?php

namespace App\Debug;

/**
 * A traceable PDO statement to use with Traceablepdo.
 */
class DebugBarStatement extends \PDOStatement
{
}
